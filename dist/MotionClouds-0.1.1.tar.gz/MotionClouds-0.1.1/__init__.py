#/usr/bin/env python
# -*- coding: utf-8 -*- 
__author__ = "Laurent Perrinet INT - CNRS"
__version__ = 'JNP'
__all__ = ["MotionClouds"]
